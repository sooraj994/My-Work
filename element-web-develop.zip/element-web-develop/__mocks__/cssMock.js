module.exports = "css-file-stub";
