declare module '!!raw-loader!*' {
    const contents: string;
    export default contents;
}
